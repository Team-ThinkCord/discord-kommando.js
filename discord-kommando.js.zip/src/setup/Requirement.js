class Requirement {
    constructor(name) {
        if (typeof name != "string") throw new TypeError("Name is string. not " + typeof name + ".");
        this.name = name;
    }
    
    handle(callback) {
        this.callback = callback;
    }
    
    on(logic) {
        this.logic = logic;
    }
    
    call(msg, args) {
        if (this.logic) this.callback(msg, args);
    }
}

/*
 * 머리를 써보자..
 * 머리머리머리머리
 * 민머리 대머리 맨들맨들 빡빡이
*/