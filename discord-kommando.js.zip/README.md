# discord-kommando.js
an Automatic command handler for discord.js
